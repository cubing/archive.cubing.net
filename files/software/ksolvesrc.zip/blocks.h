
#include "data.h"

#ifndef BLOCKS_H
#define BLOCKS_H

bool blocklegal(map<string, substate>& state, set<map<string, set<int> > >& blocks, map<string, submove>& move);

#endif
