
using namespace std;

#ifndef CHECKS_H
#define CHECKS_H

bool uniquePermutation( vector<int> test);
bool uniquePermutation(int test[], int size);

#endif
