
#include "data.h"
using namespace std;

#ifndef SEARCH_H
#define SEARCH_H

bool TreeSolve(map<string, substate> state, map<string, substate>& solved, map<string, map<string, submove> >& moves, map<string, dataset>& datasets, map<string, subprune>& prunetables, set< pair< string, string> >& forbiddenPairs, map<string, substate>& ignore, set<map<string, set<int> > >& blocks, int depth, string sequence, string old_move);

bool isSolved(map<string, substate> state1, map<string, substate>& state2, map<string, substate>& ignore);

#endif
