
// Functions for generating the tables telling you where you
// go by applying move X to index i.

#ifndef MOVETABLES_H
#define MOVETABLES_H




#endif
