
// Functions for reading the puzzle states to be solved
#include "data.h"
#include <string>

#ifndef SCRAMBLE_H
#define SCRAMBLE_H

using namespace std;

class scramble
{
public:
   scramble(string, map<string, dataset>);
   void print(void); // for debugging
   map<string, substate> getScramble();
   string scramble::getName();
   int scramble::getMaxDepth();
private:      
   vector< map<string, substate> > states;
   vector< int > max_depths;
   vector<string> names;
   int sent;
};

#endif
