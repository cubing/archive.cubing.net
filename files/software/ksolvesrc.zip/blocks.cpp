#include "blocks.h"

bool blocklegal(map<string, substate>& state, set<map<string, set<int> > >& blocks, map<string, submove>& move){
   map< string, set<int> > changed;
   map<string, submove>::iterator iter;
   for(iter = move.begin(); iter != move.end(); iter++){
      int setsize = iter->second.size;
      for(int i = 0; i < setsize; i++){
         if( iter->second.permute[i] != i+1 )
            changed[ (*iter).first ].insert(state[ (*iter).first ].permutation[i]);
         else if( iter->second.orient[i] != 0 )
            changed[ (*iter).first ].insert(state[ (*iter).first ].permutation[i]);
      }
   }
   
   set<map<string, set<int> > >::iterator block_iter;
   map<string, set<int> >::iterator set_iter;
   set<int>::iterator piece_iter;
   for(block_iter = blocks.begin(); block_iter != blocks.end(); block_iter++){
      bool block_moved = true;
      bool block_stationary = true;
      
      map<string, set<int> > test = (*block_iter);
      for(set_iter = test.begin(); set_iter != test.end(); set_iter++){
//      for(set_iter = (*block_iter).begin(); set_iter != (*block_iter).end(); set_iter++){
         for( piece_iter = set_iter->second.begin(); piece_iter != set_iter->second.end(); piece_iter++){
            if( changed[ (*set_iter).first ].find(*piece_iter) == changed[ (*set_iter).first ].end() )
               block_moved = false;
            else 
               block_stationary = false;
         }
      }
      if( !block_moved && !block_stationary )
         return false;
   }
   return true;
}
