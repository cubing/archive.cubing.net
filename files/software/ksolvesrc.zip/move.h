
// Functions for applying moves to pusslestates or single vectors.

#include "data.h"
using namespace std;

#ifndef MOVE_H
#define MOVE_H

//map<string, substate> applyMove(map<string, substate> state, map<string, submove>& move, map<string, dataset>& datasets);
void applyMove(map<string, substate>& state, map<string, substate>& new_state, map<string, submove>& move, map<string, dataset>& datasets);

// Takes two moves and add them up to a single move. Eg R R => R2
map<string, submove> mergeMoves(map<string, submove> move1, map<string, submove> move2, map<string, dataset>& datasets);

//vector<int> applySubmoveO(vector<int> orientation, vector<int> change_o, vector<int> change_p, int omod);
//vector<int> applySubmoveP(vector<int> permutation, vector<int> change_p);
vector<int> applySubmoveO(vector<int> orientation, int change_o[], int change_p[], int size, int omod);
vector<int> applySubmoveP(vector<int> permutation, int change_p[], int size);
int* applySubmoveP(int permutation[], int change_p[], int size);

#endif
