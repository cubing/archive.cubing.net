
public final class Turn4 {
  public static final int U1 = 0;
  public static final int U2 = 1;
  public static final int U3 = 2;
  public static final int F1 = 3;
  public static final int F2 = 4;
  public static final int F3 = 5;
  public static final int L1 = 6;
  public static final int L2 = 7;
  public static final int L3 = 8;
  public static final int Uu1 = 9;
  public static final int Uu2 = 10;
  public static final int Uu3 = 11;
  public static final int Ff1 = 12;
  public static final int Ff2 = 13;
  public static final int Ff3 = 14;
  public static final int Ll1 = 15;
  public static final int Ll2 = 16;
  public static final int Ll3 = 17;
  public static final int u1 = 18;
  public static final int u2 = 19;
  public static final int u3 = 20;
  public static final int d1 = 21;
  public static final int d2 = 22;
  public static final int d3 = 23;
  public static final int f1 = 24;
  public static final int f2 = 25;
  public static final int f3 = 26;
  public static final int b1 = 27;
  public static final int b2 = 28;
  public static final int b3 = 29;
  public static final int l1 = 30;
  public static final int l2 = 31;
  public static final int l3 = 32;
  public static final int r1 = 33;
  public static final int r2 = 34;
  public static final int r3 = 35;
  public static final int ud1 = 36;
  public static final int ud2 = 37;
  public static final int ud3 = 38;
  public static final int fb1 = 39;
  public static final int fb2 = 40;
  public static final int fb3 = 41;
  public static final int lr1 = 42;
  public static final int lr2 = 43;
  public static final int lr3 = 44;
  public static final int UU1 = 45;
  public static final int UU2 = 46;
  public static final int UU3 = 47;
  public static final int FF1 = 48;
  public static final int FF2 = 49;
  public static final int FF3 = 50;
  public static final int LL1 = 51;
  public static final int LL2 = 52;
  public static final int LL3 = 53;
  public static final int NUM = 54;

  public static final int MASK_U = 1;
  public static final int MASK_F = 2;
  public static final int MASK_L = 4;
  public static final int MASK_u = 8;
  public static final int MASK_d = 16;
  public static final int MASK_f = 32;
  public static final int MASK_b = 64;
  public static final int MASK_l = 128;
  public static final int MASK_r = 256;
  public static final int MASK_Uu = 512;
  public static final int MASK_Ff = 1024;
  public static final int MASK_Ll = 2048;
  public static final int MASK_ud = 4096;
  public static final int MASK_fb = 8192;
  public static final int MASK_lr = 16384;
  public static final int MASK_UU = 32768;
  public static final int MASK_FF = 65536;
  public static final int MASK_LL = 131072;

  public static final int[] turnMask = {
    MASK_U, MASK_U, MASK_U,
    MASK_F, MASK_F, MASK_F,
    MASK_L, MASK_L, MASK_L,
    MASK_Uu, MASK_Uu, MASK_Uu,
    MASK_Ff, MASK_Ff, MASK_Ff,
    MASK_Ll, MASK_Ll, MASK_Ll,
    MASK_u, MASK_u, MASK_u,
    MASK_d, MASK_d, MASK_d,
    MASK_f, MASK_f, MASK_f,
    MASK_b, MASK_b, MASK_b,
    MASK_l, MASK_l, MASK_l,
    MASK_r, MASK_r, MASK_r,
    MASK_ud, MASK_ud, MASK_ud,
    MASK_fb, MASK_fb, MASK_fb,
    MASK_lr, MASK_lr, MASK_lr,
    MASK_UU, MASK_UU, MASK_UU,
    MASK_FF, MASK_FF, MASK_FF,
    MASK_LL, MASK_LL, MASK_LL,
  };

  private Turn4() {}
}
