
public final class CubeState4 {
  public int coActive;
  public int cActive;
  public int mActive;
  public int eActive;

  public int cornTwist;
  public int cornPerm;
  public int midLocU;
  public int midLocD;
  public int midLocF;
  public int midLocB;
  public int midLocL;
  public int midLocR;
  public int edgePosUF;
  public int edgePosUR;
  public int edgePosUB;
  public int edgePosUL;
  public int edgePosDF;
  public int edgePosDR;
  public int edgePosDB;
  public int edgePosDL;
  public int edgePosFR;
  public int edgePosFL;
  public int edgePosBR;
  public int edgePosBL;
  // additional values
  public int aCornPerm;
  public int oCornPerm;

  public int turnMask; // 9-bit mask of allowed turns (r l b f d u L F U)

  public int minimum;
  public int depth;
}
