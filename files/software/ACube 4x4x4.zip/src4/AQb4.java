
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;

public final class AQb4 {
  public static void main(String[] args) {
    InputStreamReader isr = new InputStreamReader(System.in);
    BufferedReader br = new BufferedReader(isr);
    CubeReader4 cubeReader = new CubeReader4();
    System.err.println("AQb4 0.2");
    System.err.println(" by Josef Jelinek 2004");
    System.err.println();
    while (true) {
      System.err.println("Enter a cube configuration:");
      System.err.println("UF UF UR UR UB UB UL UL DF DF DR DR DB DB DL DL FR FR FL FL BR BR BL BL  UFR URB UBL ULF DRF DFL DLB  U U U U D D D D F F F F B B B B L L L L R R R R");
      String input = readLine(br);
      if (input == null)
        break;
      if (input.trim().equals(""))
        continue;
      String r = cubeReader.init(input);
      /* returns String to signal success or error */
      if (r == "QUIT")
        break;
      if (r == "OK") {
        System.out.println();
        System.out.println(input);
        cubeReader.solve();
      }
      else if (r == "NEW") {
        System.err.println("Canceled.");
      }
      else {
        System.out.println();
        System.out.println(input);
        System.out.println("Error: " + r + ".");
        System.err.println("Error: " + r + ".");
      }
    }
    System.err.println();
    System.err.println("Have a nice day.");
  }

  public static String readLine(BufferedReader br) {
    try {
      String s = br.readLine();
      return s;
    }
    catch (IOException e) {
      System.err.println("Input error: " + e);
    }
    return null;
  }
}
