public final class TransformEdgePos4 {
  public short[][] turn;
  private PackEdgePos4 pack;

  private static final String[] txt =
    {"UF", "UR", "UB", "UL", "DF", "DR", "DB", "DL", "FR", "FL", "BR", "BL"};

  public TransformEdgePos4(int eActive, int pos) {
    System.err.print(" " + txt[pos / 2] + " edge position:");
    pack = new PackEdgePos4(eActive, pos);
    int n = pack.len();
    turn = new short[Turn4.NUM][n];
    for (int i = 0; i < n; i++) {
      turn[Turn4.U1][i] = up(i);
      turn[Turn4.F1][i] = front(i);
      turn[Turn4.L1][i] = left(i);
      turn[Turn4.Uu1][i] = up(mup(i));
      turn[Turn4.Ff1][i] = front(mfront(i));
      turn[Turn4.Ll1][i] = left(mleft(i));
      turn[Turn4.ud1][i] = mup(mdown(mdown(mdown(i))));
      turn[Turn4.fb1][i] = mfront(mback(mback(mback(i))));
      turn[Turn4.lr1][i] = mleft(mright(mright(mright(i))));
      turn[Turn4.UU1][i] = up(mup(mdown(mdown(mdown(i)))));
      turn[Turn4.FF1][i] = front(mfront(mback(mback(mback(i)))));
      turn[Turn4.LL1][i] = left(mleft(mright(mright(mright(i)))));
      turn[Turn4.u1][i] = mup(i);
      turn[Turn4.d1][i] = mdown(i);
      turn[Turn4.f1][i] = mfront(i);
      turn[Turn4.b1][i] = mback(i);
      turn[Turn4.l1][i] = mleft(i);
      turn[Turn4.r1][i] = mright(i);
    }
    for (int i = 0; i < n; i++) {
      turn[Turn4.U2][i] = turn[Turn4.U1][turn[Turn4.U1][i]];
      turn[Turn4.F2][i] = turn[Turn4.F1][turn[Turn4.F1][i]];
      turn[Turn4.L2][i] = turn[Turn4.L1][turn[Turn4.L1][i]];
      turn[Turn4.Uu2][i] = turn[Turn4.Uu1][turn[Turn4.Uu1][i]];
      turn[Turn4.Ff2][i] = turn[Turn4.Ff1][turn[Turn4.Ff1][i]];
      turn[Turn4.Ll2][i] = turn[Turn4.Ll1][turn[Turn4.Ll1][i]];
      turn[Turn4.ud2][i] = turn[Turn4.ud1][turn[Turn4.ud1][i]];
      turn[Turn4.fb2][i] = turn[Turn4.fb1][turn[Turn4.fb1][i]];
      turn[Turn4.lr2][i] = turn[Turn4.lr1][turn[Turn4.lr1][i]];
      turn[Turn4.UU2][i] = turn[Turn4.UU1][turn[Turn4.UU1][i]];
      turn[Turn4.FF2][i] = turn[Turn4.FF1][turn[Turn4.FF1][i]];
      turn[Turn4.LL2][i] = turn[Turn4.LL1][turn[Turn4.LL1][i]];
      turn[Turn4.u2][i] = turn[Turn4.u1][turn[Turn4.u1][i]];
      turn[Turn4.d2][i] = turn[Turn4.d1][turn[Turn4.d1][i]];
      turn[Turn4.f2][i] = turn[Turn4.f1][turn[Turn4.f1][i]];
      turn[Turn4.b2][i] = turn[Turn4.b1][turn[Turn4.b1][i]];
      turn[Turn4.l2][i] = turn[Turn4.l1][turn[Turn4.l1][i]];
      turn[Turn4.r2][i] = turn[Turn4.r1][turn[Turn4.r1][i]];
    }
    for (int i = 0; i < n; i++) {
      turn[Turn4.U3][i] = turn[Turn4.U2][turn[Turn4.U1][i]];
      turn[Turn4.F3][i] = turn[Turn4.F2][turn[Turn4.F1][i]];
      turn[Turn4.L3][i] = turn[Turn4.L2][turn[Turn4.L1][i]];
      turn[Turn4.Uu3][i] = turn[Turn4.Uu2][turn[Turn4.Uu1][i]];
      turn[Turn4.Ff3][i] = turn[Turn4.Ff2][turn[Turn4.Ff1][i]];
      turn[Turn4.Ll3][i] = turn[Turn4.Ll2][turn[Turn4.Ll1][i]];
      turn[Turn4.ud3][i] = turn[Turn4.ud2][turn[Turn4.ud1][i]];
      turn[Turn4.fb3][i] = turn[Turn4.fb2][turn[Turn4.fb1][i]];
      turn[Turn4.lr3][i] = turn[Turn4.lr2][turn[Turn4.lr1][i]];
      turn[Turn4.UU3][i] = turn[Turn4.UU2][turn[Turn4.UU1][i]];
      turn[Turn4.FF3][i] = turn[Turn4.FF2][turn[Turn4.FF1][i]];
      turn[Turn4.LL3][i] = turn[Turn4.LL2][turn[Turn4.LL1][i]];
      turn[Turn4.u3][i] = turn[Turn4.u2][turn[Turn4.u1][i]];
      turn[Turn4.d3][i] = turn[Turn4.d2][turn[Turn4.d1][i]];
      turn[Turn4.f3][i] = turn[Turn4.f2][turn[Turn4.f1][i]];
      turn[Turn4.b3][i] = turn[Turn4.b2][turn[Turn4.b1][i]];
      turn[Turn4.l3][i] = turn[Turn4.l2][turn[Turn4.l1][i]];
      turn[Turn4.r3][i] = turn[Turn4.r2][turn[Turn4.r1][i]];
    }
    System.err.println(" " + n + " items per turn.");
  }

  private short up(int s) {
    pack.unpack(s);
    pack.cycle(0, 2, 4, 6);
    pack.cycle(1, 3, 5, 7);
    return (short)pack.pack();
  }

  private short front(int s) {
    pack.unpack(s);
    pack.cycle(0, 19, 9, 16);
    pack.cycle(1, 18, 8, 17);
    return (short)pack.pack();
  }

  private short left(int s) {
    pack.unpack(s);
    pack.cycle(6, 23, 15, 18);
    pack.cycle(7, 22, 14, 19);
    return (short)pack.pack();
  }

  private short mup(int s) {
    pack.unpack(s);
    pack.cycle(16, 20, 22, 18);
    return (short)pack.pack();
  }

  private short mdown(int s) {
    pack.unpack(s);
    pack.cycle(17, 19, 23, 21);
    return (short)pack.pack();
  }

  private short mfront(int s) {
    pack.unpack(s);
    pack.cycle(2, 7, 15, 10);
    return (short)pack.pack();
  }

  private short mback(int s) {
    pack.unpack(s);
    pack.cycle(3, 11, 14, 6);
    return (short)pack.pack();
  }

  private short mleft(int s) {
    pack.unpack(s);
    pack.cycle(0, 5, 13, 8);
    return (short)pack.pack();
  }

  private short mright(int s) {
    pack.unpack(s);
    pack.cycle(1, 9, 12, 4);
    return (short)pack.pack();
  }
}
