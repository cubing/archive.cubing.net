+>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>+
|  AQb4 - 4x4x4 Cube Solving Program  |
+<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<+

(c) 2004 Josef Jelinek <gloom@email.cz> <http://rubikscube.info>

AQb4 is a modification of ACube3 program to solve - even incomplete - 4x4x4
Rubik's cube (Rubik Revenge, Rubik's Master Cube, ...).

Since 4x4x4 cube is much more complicated than 3x3x3 one, this program has
quite serious limits to be used to solve any general configuration.
However, it can be very useful for finding short sequences to accomplish
some tasks that are very difficult to figure out by intuition or other standard
ways (commutators, conjugates, etc.)...
Significant speed-up can be reached by restricting turns, which often enables
to find optimal or suboptimal solution which is nice because it uses only
specified layers... In such a case you can search to higher depths than 12..
In most cases when the turns are not restricted the depth 10-12 is the
limit of current computers... In such cases, this program can be at least
used to prove lower bounds of the number of turns required ;).
(e.g. orientation parity fix has at least 12 turns, but I could not find
one... however, ignoring F and U centers and restricting turns, you can find
this sequence for parity fix: r2 F u' F' U2 F u F r' F2 U2 r2, which is 12
turns long and can be sometimes useful)...

-------------
Requirements:
-------------
Java Runtime (any version should be ok after recompilation) 1.3+ recommended
256MB memory, some MB of free disk space, faster processor

---------
Starting:
---------
  run4                       - for windows-like OS
  java -cp AQb4.jar AQb4     - for any platform

If the Java Runtime repports "Out of memory", try to increase maximum heap
by e.g. -Xmx400MB argument (if supported) - only for high memory peaks when
garbage collector does not do its job quickly...

There are no command line arguments (unlike for ACube3)...

The program generates some tables to the disk as needed, but they can
be deleted at any time and they are regenerated if necessary...
However these tables speeds-up some initialization phases of searching,
so if you have some disk space, let them exist.
There are many various messages displayed during searching and initializing
that are not important... they are used for feed-back...

------
Input:
------
When started, the program asks for a cube configuration to be solved.
There are many cubies on 4x4x4, so the input is quite complicated.
I would recommend writing inputs to a text file and running the program
using stdin/stdout redirection (<input.txt >output.txt).
Some things are written to stderr, so you have some feedback what is happening.

Input configuration format:

The configuration must be on ONE line including other commands to control the
searching. All cubies and commands must be separated by whitespaces.
Put all the commands before specifying cubies.

Commands:
 Q          - Quit - terminates the program
 N          - New - discards this line and tries to read another configuration
              (usefull as a comment in an input file)
 OOOOOO     - Turn Mask - a string of 1 to 6 octal digits determining triples
              of bits to enable or disable the particular turn.
              If any digits are missing at the end, they are replaced by 7s.
              The order of bits in triples corresponding to turns is this:
              U F L / u d f / b l r / Uu Ff Ll / ud' fb' lr' / Uud' Ffb' Llr'
              (the meaning will be described later)
              example: using only "outer" turns: 700707
              example: using only up/front turns: 650600
              example: using only single layer turns: 777000

Cubies:
 There are three groups of cubies Edges, Corners, and Centers.
 Edged are determined only by their position (no orientation is used,
 because one edge can appear in a particular position in only one orientation).
 Centers are also determined by their position.
 Corners are determined by their position and orientation.

Edges:
 - specified by doubles of characters from U, D, F, B, L, R (e.g. UF, BL, ..)
 Position order:

  UF(left) UF(right) UR(front) UR(back) UB(right) UB(left) UL(back) UL(front)
  DF(left) DF(right) DR(front) DR(back) DB(right) DB(left) DL(back) DL(front)
  FR(top) FR(bottom) FL(top) FL(bottom) BR(top) BR(bottom) BL(top) BL(bottom)

 Shortcuts:
  ! - edge in its position
  ? - unknown edge in the position

Corners:
 - similar to ACube
 - there are only 7 corners adjustable on 4x4x4, DBR corner is fixed in
   its position (see bellow the "output" section)

Centers:
 - specified by single characters U, D, F, B, L, or R
 Position order:

  U(b-l) U(b-r) U(f-r) U(f-l)  D(f-l) D(f-r) D(b-r) D(b-l)
  F(u-l) F(u-r) F(d-r) F(d-l)  B(u-r) B(u-l) B(d-l) B(d-r)
  L(u-b) L(u-f) L(d-f) L(d-b)  R(u-f) R(u-b) R(d-b) R(d-f)
  (I hope it is correct - email me, if any inconsistency)

 Shortcuts: same as for edges

Multi-Cubie Shortcuts:
 To simplify the input sequence you can use several shortcuts for the
 edge/corner/center cubie group.

 Edge group:
  !!  - set ! to the rest of edges
  ??  - set ? to the rest of edges
 Corner group:
  !!  - set ! to the rest of edges
  @!! - set @! to the rest of edges
  ??  - set ? to the rest of edges
  @?? - set @? to the rest of edges
 Center group:
  !!  - set ! to the rest of edges
  ??  - set ? to the rest of edges

---------------------------
Output Sequences and Turns:
---------------------------
Because 4x4x4 has no fixed centers as 3x3x3 is is not clear how to handle
the cube rotations etc.
AQb4 uses one trick to simplify searching and managing the cube -
The DBR corner is fixed in its position and cannot move.
This corner determines the whole cube orientation.
This means that we cannot use D, B, and R turns, which is quite odd, but
in order to make program fully functionable, these are replaced by 3-layer
turns of the 3 adjacent layers on the cube...

Turn Types:
U F L          - single layer turn
Uu Ff Ll       - double layer turn (the outer layer and one adjacent inner layer
                 together)
Uud' Ffb' Llr' - triple layer turn (the outer layer and two adjacent inner layers)
u d f b l r    - turn of single inner layer adjacent to the corresponding outer
                 layers
ud' fb' lr'    - turn of two adjacent inner layers together

Modifiers:
 - standard apostrophe and 2 digit are used
 - modifiers are used on each letter in a group:
   U' F' L' U2 F2 L2
   U'u' F'f' L'l' U2u2 F2f2 L2l2
   U'u'd F'f'b L'l'r U2u2d2 F2f2b2 L2l2r2
   u' d' f' b' l' r' u2 d2 f2 b2 l2 r2
   u'd f'b l'r u2d2 f2b2 l2r2

I would like to hear about any problems or interesting results.

Enjoy it.
   
