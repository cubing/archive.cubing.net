#define  CENTER_UFL              0
#define  CENTER_UBL              1
#define  CENTER_UBR              2
#define  CENTER_UFR              3
#define  CENTER_DBL              4
#define  CENTER_DFL              5
#define  CENTER_DFR              6
#define  CENTER_DBR              7
#define  CENTER_FDL              8
#define  CENTER_FUL              9
#define  CENTER_FUR              10
#define  CENTER_FDR              11
#define  CENTER_BDR              12
#define  CENTER_BUR              13
#define  CENTER_BUL              14
#define  CENTER_BDL              15
#define  CENTER_LDB              16
#define  CENTER_LUB              17
#define  CENTER_LUF              18
#define  CENTER_LDF              19
#define  CENTER_RDF              20
#define  CENTER_RUF              21
#define  CENTER_RUB              22
#define  CENTER_RDB              23

#define  CENTER_NUMBER           24
#define  CENTER_NUMBER_IN_PACK   4
#define  CENTER_MAX_PACK         10626


unsigned short rotate_U_on_center(unsigned short);

unsigned short rotate_F_on_center(unsigned short);

unsigned short rotate_R_on_center(unsigned short);

unsigned short rotate_u_on_center(unsigned short);

unsigned short rotate_d_on_center(unsigned short);

unsigned short rotate_f_on_center(unsigned short);

unsigned short rotate_b_on_center(unsigned short);

unsigned short rotate_r_on_center(unsigned short);

unsigned short rotate_l_on_center(unsigned short);

