#include "main.h"

#define  COLOR_WHITE    0
#define  COLOR_YELLOW   1
#define  COLOR_RED      2
#define  COLOR_ORANGE   3
#define  COLOR_GREEN    4
#define  COLOR_BLUE     5

#define  COLOR_FACE_F   0
#define  COLOR_FACE_B   1
#define  COLOR_FACE_R   2
#define  COLOR_FACE_L   3
#define  COLOR_FACE_U   4
#define  COLOR_FACE_D   5

#define  COLOR_NUMBER   6

char opposite_color(char);

state input(int*);
