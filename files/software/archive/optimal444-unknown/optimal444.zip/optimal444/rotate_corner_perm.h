#define  CORNER_UBL              0
#define  CORNER_UBR              1
#define  CORNER_UFR              2
#define  CORNER_UFL              3

#define  CORNER_DFL              4
#define  CORNER_DFR              5
#define  CORNER_DBR              6

#define  CORNER_PERM_NUMBER      7
#define  CORNER_PERM_MAX_PACK    5040


unsigned short rotate_F_on_corner_perm(unsigned short);

unsigned short rotate_R_on_corner_perm(unsigned short);

unsigned short rotate_U_on_corner_perm(unsigned short);

