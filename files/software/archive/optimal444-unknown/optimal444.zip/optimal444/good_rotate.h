#include "fill_rotate.h"

void fill_next_good_rotate(char (*)[ROTATE_NUMBER+1], int*);
