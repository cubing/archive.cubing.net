
#define  EDGE_UFR            0
#define  EDGE_UFL            1
#define  EDGE_ULF            2

#define  EDGE_ULB            3
#define  EDGE_UBL            4
#define  EDGE_UBR            5

#define  EDGE_URB            6
#define  EDGE_URF            7
#define  EDGE_FLU            8

#define  EDGE_FLD            9
#define  EDGE_BLU            10
#define  EDGE_BLD            11

#define  EDGE_BRU            12
#define  EDGE_BRD            13
#define  EDGE_FRU            14

#define  EDGE_FRD            15
#define  EDGE_DFR            16
#define  EDGE_DFL            17

#define  EDGE_DLF            18
#define  EDGE_DLB            19
#define  EDGE_DBL            20

#define  EDGE_DBR            21
#define  EDGE_DRB            22
#define  EDGE_DRF            23

#define  EDGE_PACK_UFR            1
#define  EDGE_PACK_UFL            2
#define  EDGE_PACK_ULF            3

#define  EDGE_PACK_ULB            1
#define  EDGE_PACK_UBL            2
#define  EDGE_PACK_UBR            3

#define  EDGE_PACK_URB            1
#define  EDGE_PACK_URF            2
#define  EDGE_PACK_FLU            3

#define  EDGE_PACK_FLD            1
#define  EDGE_PACK_BLU            2
#define  EDGE_PACK_BLD            3

#define  EDGE_PACK_BRU            1
#define  EDGE_PACK_BRD            2
#define  EDGE_PACK_FRU            3

#define  EDGE_PACK_FRD            1
#define  EDGE_PACK_DFR            2
#define  EDGE_PACK_DFL            3

#define  EDGE_PACK_DLF            1
#define  EDGE_PACK_DLB            2
#define  EDGE_PACK_DBL            3

#define  EDGE_PACK_DBR            1
#define  EDGE_PACK_DRB            2
#define  EDGE_PACK_DRF            3

#define  EDGE_MAX_PACK       12144
#define  EDGE_NUMBER         24
#define  EDGE_NUMBER_IN_PACK 3


unsigned short rotate_R_on_edge(unsigned short);

unsigned short rotate_U_on_edge(unsigned short);

unsigned short rotate_F_on_edge(unsigned short);

unsigned short rotate_r_on_edge(unsigned short);

unsigned short rotate_l_on_edge(unsigned short);

unsigned short rotate_u_on_edge(unsigned short);

unsigned short rotate_d_on_edge(unsigned short);

unsigned short rotate_f_on_edge(unsigned short);

unsigned short rotate_b_on_edge(unsigned short);

