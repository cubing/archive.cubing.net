#include "rotate_center.h"
#include "pack.h"

unsigned short rotate_U_on_center(unsigned short center)
{
	int tab[CENTER_NUMBER];
	unpack_comb(center, tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
	four_cycle(tab,CENTER_UFR,CENTER_UFL,CENTER_UBL,CENTER_UBR);
	return pack_comb(tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
}

unsigned short rotate_F_on_center(unsigned short center)
{
	int tab[CENTER_NUMBER];
	unpack_comb(center,tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
	four_cycle(tab,CENTER_FUR,CENTER_FDR,CENTER_FDL,CENTER_FUL);
	return pack_comb(tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
}

unsigned short rotate_R_on_center(unsigned short center)
{
	int tab[CENTER_NUMBER];
	unpack_comb(center,tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
	four_cycle(tab,CENTER_RUF,CENTER_RUB,CENTER_RDB,CENTER_RDF);
	return pack_comb(tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
}

unsigned short rotate_u_on_center(unsigned short center)
{
	int tab[CENTER_NUMBER];
	unpack_comb(center,tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
	four_cycle(tab,CENTER_FUL, CENTER_LUB, CENTER_BUR, CENTER_RUF);
	four_cycle(tab,CENTER_FUR, CENTER_LUF, CENTER_BUL, CENTER_RUB);
	return pack_comb(tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
}

unsigned short rotate_d_on_center(unsigned short center)
{
	int tab[CENTER_NUMBER];
	unpack_comb(center,tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
	four_cycle(tab,CENTER_FDL, CENTER_RDF, CENTER_BDR, CENTER_LDB);
	four_cycle(tab,CENTER_FDR, CENTER_RDB, CENTER_BDL, CENTER_LDF);
	return pack_comb(tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
}

unsigned short rotate_f_on_center(unsigned short center)
{
	int tab[CENTER_NUMBER];
	unpack_comb(center,tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
	four_cycle(tab,CENTER_UFL, CENTER_RUF, CENTER_DFR, CENTER_LDF);
	four_cycle(tab,CENTER_UFR, CENTER_RDF, CENTER_DFL, CENTER_LUF);
	return pack_comb(tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
}

unsigned short rotate_b_on_center(unsigned short center)
{
	int tab[CENTER_NUMBER];
	unpack_comb(center,tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
	four_cycle(tab,CENTER_UBL, CENTER_LDB, CENTER_DBR, CENTER_RUB);
	four_cycle(tab,CENTER_UBR, CENTER_LUB, CENTER_DBL, CENTER_RDB);
	return pack_comb(tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
}

unsigned short rotate_r_on_center(unsigned short center)
{
	int tab[CENTER_NUMBER];
	unpack_comb(center,tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
	four_cycle(tab,CENTER_UFR, CENTER_BUR, CENTER_DBR, CENTER_FDR);
	four_cycle(tab,CENTER_UBR, CENTER_BDR, CENTER_DFR, CENTER_FUR);
	return pack_comb(tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
}

unsigned short rotate_l_on_center(unsigned short center)
{
	int tab[CENTER_NUMBER];
	unpack_comb(center,tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
	four_cycle(tab,CENTER_UFL, CENTER_FDL, CENTER_DBL, CENTER_BUL);
	four_cycle(tab,CENTER_UBL, CENTER_FUL, CENTER_DFL, CENTER_BDL);
	return pack_comb(tab, CENTER_NUMBER_IN_PACK, CENTER_NUMBER);
}
