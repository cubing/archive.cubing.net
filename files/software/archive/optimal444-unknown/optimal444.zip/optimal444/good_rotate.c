#include "fill_rotate.h"
#include "good_rotate.h"
#include <stdio.h>

void fill_next_good_rotate(char next_good_rotate[][ROTATE_NUMBER+1],int allowed_moves[])
{
	int i, j, k;
	char good_rotate[ROTATE_NUMBER][ROTATE_NUMBER];

	for (i = 0; i < ROTATE_NUMBER; i++)
		for (j = 0; j < ROTATE_NUMBER; j++)
			good_rotate[i][j] = 1;
	
	good_rotate[ROTATE_F][ROTATE_F] = 0;
	good_rotate[ROTATE_F][ROTATE_F2] = 0;
	good_rotate[ROTATE_F][ROTATE_F3] = 0;
	good_rotate[ROTATE_F2][ROTATE_F] = 0;
	good_rotate[ROTATE_F2][ROTATE_F2] = 0;
	good_rotate[ROTATE_F2][ROTATE_F3] = 0;
	good_rotate[ROTATE_F3][ROTATE_F] = 0;
	good_rotate[ROTATE_F3][ROTATE_F2] = 0;
	good_rotate[ROTATE_F3][ROTATE_F3] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_Ffb] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_Ffb2] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_Ffb3] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_Ffb] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_Ffb2] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_Ffb3] = 0;
	good_rotate[ROTATE_Ffb3][ROTATE_Ffb] = 0;
	good_rotate[ROTATE_Ffb3][ROTATE_Ffb2] = 0;
	good_rotate[ROTATE_Ffb3][ROTATE_Ffb3] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_F] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_F2] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_F3] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_F] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_F2] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_F3] = 0;
	good_rotate[ROTATE_Ffb3][ROTATE_F] = 0;
	good_rotate[ROTATE_Ffb3][ROTATE_F2] = 0;
	good_rotate[ROTATE_Ffb3][ROTATE_F3] = 0;
	
	
	good_rotate[ROTATE_R][ROTATE_R] = 0;
	good_rotate[ROTATE_R][ROTATE_R2] = 0;
	good_rotate[ROTATE_R][ROTATE_R3] = 0;
	good_rotate[ROTATE_R2][ROTATE_R] = 0;
	good_rotate[ROTATE_R2][ROTATE_R2] = 0;
	good_rotate[ROTATE_R2][ROTATE_R3] = 0;
	good_rotate[ROTATE_R3][ROTATE_R] = 0;
	good_rotate[ROTATE_R3][ROTATE_R2] = 0;
	good_rotate[ROTATE_R3][ROTATE_R3] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_Rrl] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_Rrl2] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_Rrl3] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_Rrl] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_Rrl2] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_Rrl3] = 0;
	good_rotate[ROTATE_Rrl3][ROTATE_Rrl] = 0;
	good_rotate[ROTATE_Rrl3][ROTATE_Rrl2] = 0;
	good_rotate[ROTATE_Rrl3][ROTATE_Rrl3] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_R] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_R2] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_R3] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_R] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_R2] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_R3] = 0;
	good_rotate[ROTATE_Rrl3][ROTATE_R] = 0;
	good_rotate[ROTATE_Rrl3][ROTATE_R2] = 0;
	good_rotate[ROTATE_Rrl3][ROTATE_R3] = 0;
	
	
	good_rotate[ROTATE_U][ROTATE_U] = 0;
	good_rotate[ROTATE_U][ROTATE_U2] = 0;
	good_rotate[ROTATE_U][ROTATE_U3] = 0;
	good_rotate[ROTATE_U2][ROTATE_U] = 0;
	good_rotate[ROTATE_U2][ROTATE_U2] = 0;
	good_rotate[ROTATE_U2][ROTATE_U3] = 0;
	good_rotate[ROTATE_U3][ROTATE_U] = 0;
	good_rotate[ROTATE_U3][ROTATE_U2] = 0;
	good_rotate[ROTATE_U3][ROTATE_U3] = 0;
	good_rotate[ROTATE_Uud][ROTATE_Uud] = 0;
	good_rotate[ROTATE_Uud][ROTATE_Uud2] = 0;
	good_rotate[ROTATE_Uud][ROTATE_Uud3] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_Uud] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_Uud2] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_Uud3] = 0;
	good_rotate[ROTATE_Uud3][ROTATE_Uud] = 0;
	good_rotate[ROTATE_Uud3][ROTATE_Uud2] = 0;
	good_rotate[ROTATE_Uud3][ROTATE_Uud3] = 0;
	good_rotate[ROTATE_Uud][ROTATE_U] = 0;
	good_rotate[ROTATE_Uud][ROTATE_U2] = 0;
	good_rotate[ROTATE_Uud][ROTATE_U3] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_U] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_U2] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_U3] = 0;
	good_rotate[ROTATE_Uud3][ROTATE_U] = 0;
	good_rotate[ROTATE_Uud3][ROTATE_U2] = 0;
	good_rotate[ROTATE_Uud3][ROTATE_U3] = 0;
	
	
	good_rotate[ROTATE_f][ROTATE_f] = 0;
	good_rotate[ROTATE_f][ROTATE_f2] = 0;
	good_rotate[ROTATE_f][ROTATE_f3] = 0;
	good_rotate[ROTATE_f2][ROTATE_f] = 0;
	good_rotate[ROTATE_f2][ROTATE_f2] = 0;
	good_rotate[ROTATE_f2][ROTATE_f3] = 0;
	good_rotate[ROTATE_f3][ROTATE_f] = 0;
	good_rotate[ROTATE_f3][ROTATE_f2] = 0;
	good_rotate[ROTATE_f3][ROTATE_f3] = 0;
	good_rotate[ROTATE_b][ROTATE_b] = 0;
	good_rotate[ROTATE_b][ROTATE_b2] = 0;
	good_rotate[ROTATE_b][ROTATE_b3] = 0;
	good_rotate[ROTATE_b2][ROTATE_b] = 0;
	good_rotate[ROTATE_b2][ROTATE_b2] = 0;
	good_rotate[ROTATE_b2][ROTATE_b3] = 0;
	good_rotate[ROTATE_b3][ROTATE_b] = 0;
	good_rotate[ROTATE_b3][ROTATE_b2] = 0;
	good_rotate[ROTATE_b3][ROTATE_b3] = 0;
	good_rotate[ROTATE_b][ROTATE_f] = 0;
	good_rotate[ROTATE_b][ROTATE_f2] = 0;
	good_rotate[ROTATE_b][ROTATE_f3] = 0;
	good_rotate[ROTATE_b2][ROTATE_f] = 0;
	good_rotate[ROTATE_b2][ROTATE_f2] = 0;
	good_rotate[ROTATE_b2][ROTATE_f3] = 0;
	good_rotate[ROTATE_b3][ROTATE_f] = 0;
	good_rotate[ROTATE_b3][ROTATE_f2] = 0;
	good_rotate[ROTATE_b3][ROTATE_f3] = 0;
	
	
	good_rotate[ROTATE_r][ROTATE_r] = 0;
	good_rotate[ROTATE_r][ROTATE_r2] = 0;
	good_rotate[ROTATE_r][ROTATE_r3] = 0;
	good_rotate[ROTATE_r2][ROTATE_r] = 0;
	good_rotate[ROTATE_r2][ROTATE_r2] = 0;
	good_rotate[ROTATE_r2][ROTATE_r3] = 0;
	good_rotate[ROTATE_r3][ROTATE_r] = 0;
	good_rotate[ROTATE_r3][ROTATE_r2] = 0;
	good_rotate[ROTATE_r3][ROTATE_r3] = 0;
	good_rotate[ROTATE_l][ROTATE_l] = 0;
	good_rotate[ROTATE_l][ROTATE_l2] = 0;
	good_rotate[ROTATE_l][ROTATE_l3] = 0;
	good_rotate[ROTATE_l2][ROTATE_l] = 0;
	good_rotate[ROTATE_l2][ROTATE_l2] = 0;
	good_rotate[ROTATE_l2][ROTATE_l3] = 0;
	good_rotate[ROTATE_l3][ROTATE_l] = 0;
	good_rotate[ROTATE_l3][ROTATE_l2] = 0;
	good_rotate[ROTATE_l3][ROTATE_l3] = 0;
	good_rotate[ROTATE_l][ROTATE_r] = 0;
	good_rotate[ROTATE_l][ROTATE_r2] = 0;
	good_rotate[ROTATE_l][ROTATE_r3] = 0;
	good_rotate[ROTATE_l2][ROTATE_r] = 0;
	good_rotate[ROTATE_l2][ROTATE_r2] = 0;
	good_rotate[ROTATE_l2][ROTATE_r3] = 0;
	good_rotate[ROTATE_l3][ROTATE_r] = 0;
	good_rotate[ROTATE_l3][ROTATE_r2] = 0;
	good_rotate[ROTATE_l3][ROTATE_r3] = 0;
	
	
	good_rotate[ROTATE_u][ROTATE_u] = 0;
	good_rotate[ROTATE_u][ROTATE_u2] = 0;
	good_rotate[ROTATE_u][ROTATE_u3] = 0;
	good_rotate[ROTATE_u2][ROTATE_u] = 0;
	good_rotate[ROTATE_u2][ROTATE_u2] = 0;
	good_rotate[ROTATE_u2][ROTATE_u3] = 0;
	good_rotate[ROTATE_u3][ROTATE_u] = 0;
	good_rotate[ROTATE_u3][ROTATE_u2] = 0;
	good_rotate[ROTATE_u3][ROTATE_u3] = 0;
	good_rotate[ROTATE_d][ROTATE_d] = 0;
	good_rotate[ROTATE_d][ROTATE_d2] = 0;
	good_rotate[ROTATE_d][ROTATE_d3] = 0;
	good_rotate[ROTATE_d2][ROTATE_d] = 0;
	good_rotate[ROTATE_d2][ROTATE_d2] = 0;
	good_rotate[ROTATE_d2][ROTATE_d3] = 0;
	good_rotate[ROTATE_d3][ROTATE_d] = 0;
	good_rotate[ROTATE_d3][ROTATE_d2] = 0;
	good_rotate[ROTATE_d3][ROTATE_d3] = 0;
	good_rotate[ROTATE_d][ROTATE_u] = 0;
	good_rotate[ROTATE_d][ROTATE_u2] = 0;
	good_rotate[ROTATE_d][ROTATE_u3] = 0;
	good_rotate[ROTATE_d2][ROTATE_u] = 0;
	good_rotate[ROTATE_d2][ROTATE_u2] = 0;
	good_rotate[ROTATE_d2][ROTATE_u3] = 0;
	good_rotate[ROTATE_d3][ROTATE_u] = 0;
	good_rotate[ROTATE_d3][ROTATE_u2] = 0;
	good_rotate[ROTATE_d3][ROTATE_u3] = 0;
	
	good_rotate[ROTATE_F][ROTATE_f] = 0;
	good_rotate[ROTATE_F][ROTATE_f2] = 0;
	good_rotate[ROTATE_F][ROTATE_f3] = 0;
	good_rotate[ROTATE_F2][ROTATE_f] = 0;
	good_rotate[ROTATE_F2][ROTATE_f2] = 0;
	good_rotate[ROTATE_F2][ROTATE_f3] = 0;
	good_rotate[ROTATE_F3][ROTATE_f] = 0;
	good_rotate[ROTATE_F3][ROTATE_f2] = 0;
	good_rotate[ROTATE_F3][ROTATE_f3] = 0;
	good_rotate[ROTATE_F][ROTATE_b] = 0;
	good_rotate[ROTATE_F][ROTATE_b2] = 0;
	good_rotate[ROTATE_F][ROTATE_b3] = 0;
	good_rotate[ROTATE_F2][ROTATE_b] = 0;
	good_rotate[ROTATE_F2][ROTATE_b2] = 0;
	good_rotate[ROTATE_F2][ROTATE_b3] = 0;
	good_rotate[ROTATE_F3][ROTATE_b] = 0;
	good_rotate[ROTATE_F3][ROTATE_b2] = 0;
	good_rotate[ROTATE_F3][ROTATE_b3] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_b] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_b2] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_b3] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_b] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_b2] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_b3] = 0;
	good_rotate[ROTATE_Ffb3][ROTATE_b] = 0;
	good_rotate[ROTATE_Ffb3][ROTATE_b2] = 0;
	good_rotate[ROTATE_Ffb3][ROTATE_b3] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_f] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_f2] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_f3] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_f] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_f2] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_f3] = 0;
	good_rotate[ROTATE_Ffb3][ROTATE_f] = 0;
	good_rotate[ROTATE_Ffb3][ROTATE_f2] = 0;
	good_rotate[ROTATE_Ffb3][ROTATE_f3] = 0;
	good_rotate[ROTATE_F][ROTATE_Ffb3] = 0;
	good_rotate[ROTATE_F2][ROTATE_Ffb2] = 0;
	good_rotate[ROTATE_F3][ROTATE_Ffb] = 0;
	
	good_rotate[ROTATE_R][ROTATE_r] = 0;
	good_rotate[ROTATE_R][ROTATE_r2] = 0;
	good_rotate[ROTATE_R][ROTATE_r3] = 0;
	good_rotate[ROTATE_R2][ROTATE_r] = 0;
	good_rotate[ROTATE_R2][ROTATE_r2] = 0;
	good_rotate[ROTATE_R2][ROTATE_r3] = 0;
	good_rotate[ROTATE_R3][ROTATE_r] = 0;
	good_rotate[ROTATE_R3][ROTATE_r2] = 0;
	good_rotate[ROTATE_R3][ROTATE_r3] = 0;
	good_rotate[ROTATE_R][ROTATE_l] = 0;
	good_rotate[ROTATE_R][ROTATE_l2] = 0;
	good_rotate[ROTATE_R][ROTATE_l3] = 0;
	good_rotate[ROTATE_R2][ROTATE_l] = 0;
	good_rotate[ROTATE_R2][ROTATE_l2] = 0;
	good_rotate[ROTATE_R2][ROTATE_l3] = 0;
	good_rotate[ROTATE_R3][ROTATE_l] = 0;
	good_rotate[ROTATE_R3][ROTATE_l2] = 0;
	good_rotate[ROTATE_R3][ROTATE_l3] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_l] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_l2] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_l3] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_l] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_l2] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_l3] = 0;
	good_rotate[ROTATE_Rrl3][ROTATE_l] = 0;
	good_rotate[ROTATE_Rrl3][ROTATE_l2] = 0;
	good_rotate[ROTATE_Rrl3][ROTATE_l3] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_r] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_r2] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_r3] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_r] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_r2] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_r3] = 0;
	good_rotate[ROTATE_Rrl3][ROTATE_r] = 0;
	good_rotate[ROTATE_Rrl3][ROTATE_r2] = 0;
	good_rotate[ROTATE_Rrl3][ROTATE_r3] = 0;
	good_rotate[ROTATE_R][ROTATE_Rrl3] = 0;
	good_rotate[ROTATE_R2][ROTATE_Rrl2] = 0;
	good_rotate[ROTATE_R3][ROTATE_Rrl] = 0;
	
	good_rotate[ROTATE_U][ROTATE_u] = 0;
	good_rotate[ROTATE_U][ROTATE_u2] = 0;
	good_rotate[ROTATE_U][ROTATE_u3] = 0;
	good_rotate[ROTATE_U2][ROTATE_u] = 0;
	good_rotate[ROTATE_U2][ROTATE_u2] = 0;
	good_rotate[ROTATE_U2][ROTATE_u3] = 0;
	good_rotate[ROTATE_U3][ROTATE_u] = 0;
	good_rotate[ROTATE_U3][ROTATE_u2] = 0;
	good_rotate[ROTATE_U3][ROTATE_u3] = 0;
	good_rotate[ROTATE_U][ROTATE_d] = 0;
	good_rotate[ROTATE_U][ROTATE_d2] = 0;
	good_rotate[ROTATE_U][ROTATE_d3] = 0;
	good_rotate[ROTATE_U2][ROTATE_d] = 0;
	good_rotate[ROTATE_U2][ROTATE_d2] = 0;
	good_rotate[ROTATE_U2][ROTATE_d3] = 0;
	good_rotate[ROTATE_U3][ROTATE_d] = 0;
	good_rotate[ROTATE_U3][ROTATE_d2] = 0;
	good_rotate[ROTATE_U3][ROTATE_d3] = 0;
	good_rotate[ROTATE_Uud][ROTATE_d] = 0;
	good_rotate[ROTATE_Uud][ROTATE_d2] = 0;
	good_rotate[ROTATE_Uud][ROTATE_d3] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_d] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_d2] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_d3] = 0;
	good_rotate[ROTATE_Uud3][ROTATE_d] = 0;
	good_rotate[ROTATE_Uud3][ROTATE_d2] = 0;
	good_rotate[ROTATE_Uud3][ROTATE_d3] = 0;
	good_rotate[ROTATE_Uud][ROTATE_u] = 0;
	good_rotate[ROTATE_Uud][ROTATE_u2] = 0;
	good_rotate[ROTATE_Uud][ROTATE_u3] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_u] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_u2] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_u3] = 0;
	good_rotate[ROTATE_Uud3][ROTATE_u] = 0;
	good_rotate[ROTATE_Uud3][ROTATE_u2] = 0;
	good_rotate[ROTATE_Uud3][ROTATE_u3] = 0;
	good_rotate[ROTATE_U][ROTATE_Uud3] = 0;
	good_rotate[ROTATE_U2][ROTATE_Uud2] = 0;
	good_rotate[ROTATE_U3][ROTATE_Uud] = 0;
	
	good_rotate[ROTATE_Ffb3][ROTATE_b3] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_b2] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_b] = 0;
	good_rotate[ROTATE_b][ROTATE_Ffb] = 0;
	good_rotate[ROTATE_b2][ROTATE_Ffb2] = 0;
	good_rotate[ROTATE_b3][ROTATE_Ffb3] = 0;

	good_rotate[ROTATE_Rrl3][ROTATE_l3] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_l2] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_l] = 0;
	good_rotate[ROTATE_l][ROTATE_Rrl] = 0;
	good_rotate[ROTATE_l2][ROTATE_Rrl2] = 0;
	good_rotate[ROTATE_l3][ROTATE_Rrl3] = 0;

	good_rotate[ROTATE_Uud3][ROTATE_d3] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_d2] = 0;
	good_rotate[ROTATE_Uud][ROTATE_d] = 0;
	good_rotate[ROTATE_d][ROTATE_Uud] = 0;
	good_rotate[ROTATE_d2][ROTATE_Uud2] = 0;
	good_rotate[ROTATE_d3][ROTATE_Uud3] = 0;
	
	good_rotate[ROTATE_Ffb3][ROTATE_F] = 0;
	good_rotate[ROTATE_Ffb2][ROTATE_F2] = 0;
	good_rotate[ROTATE_Ffb][ROTATE_F3] = 0;
	good_rotate[ROTATE_F][ROTATE_Ffb3] = 0;
	good_rotate[ROTATE_F2][ROTATE_Ffb2] = 0;
	good_rotate[ROTATE_F3][ROTATE_Ffb] = 0;

	good_rotate[ROTATE_Rrl3][ROTATE_R] = 0;
	good_rotate[ROTATE_Rrl2][ROTATE_R2] = 0;
	good_rotate[ROTATE_Rrl][ROTATE_R3] = 0;
	good_rotate[ROTATE_R][ROTATE_Rrl3] = 0;
	good_rotate[ROTATE_R2][ROTATE_Rrl2] = 0;
	good_rotate[ROTATE_R3][ROTATE_Rrl] = 0;

	good_rotate[ROTATE_Uud3][ROTATE_U] = 0;
	good_rotate[ROTATE_Uud2][ROTATE_U2] = 0;
	good_rotate[ROTATE_Uud][ROTATE_U3] = 0;
	good_rotate[ROTATE_U][ROTATE_Uud3] = 0;
	good_rotate[ROTATE_U2][ROTATE_Uud2] = 0;
	good_rotate[ROTATE_U3][ROTATE_Uud] = 0;


	for (i = 0; i < ROTATE_NUMBER; i++)
		for (j = 0; j < ROTATE_NUMBER+1; j++)
			next_good_rotate[i][j] = -1;
			
	for (i = 0; i < ROTATE_NUMBER; i++)
		for (j = 0; j < ROTATE_NUMBER; j++)
			for (k = j; k < ROTATE_NUMBER; k++)
				if (allowed_moves[k] && good_rotate[i][k])
				{
					next_good_rotate[i][j] = k;
					break;
				} 
}
