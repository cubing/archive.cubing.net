#include "main.h"
#include "fill_rotate.h"

int inverse(int);

void print_rotate(int);

void print_solution(state, state, char (*)[ROTATE_NUMBER+1], int, int);
