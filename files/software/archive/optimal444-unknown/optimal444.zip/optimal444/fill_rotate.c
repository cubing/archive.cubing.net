#include "fill_rotate.h"
#include "rotate_edge.h"
#include "rotate_corner_perm.h"
#include "rotate_corner_orient.h"
#include "rotate_center.h"
#include <stdio.h>

void fill_rotate_corner_orient(unsigned short rotate_corner_orient[][ROTATE_NUMBER])
{
	unsigned short i;
	printf("fill rotate corner orient\n");

	for (i=0;i<CORNER_ORIENT_MAX_PACK;i++)
	{
		rotate_corner_orient[i][ROTATE_F] = rotate_F_on_corner_orient(i);
		rotate_corner_orient[i][ROTATE_R] = rotate_R_on_corner_orient(i);
		rotate_corner_orient[i][ROTATE_U] = rotate_U_on_corner_orient(i);
		rotate_corner_orient[i][ROTATE_F2] = rotate_F_on_corner_orient(rotate_corner_orient[i][ROTATE_F]);
		rotate_corner_orient[i][ROTATE_R2] = rotate_R_on_corner_orient(rotate_corner_orient[i][ROTATE_R]);
		rotate_corner_orient[i][ROTATE_U2] = rotate_U_on_corner_orient(rotate_corner_orient[i][ROTATE_U]);
		rotate_corner_orient[i][ROTATE_F3] = rotate_F_on_corner_orient(rotate_corner_orient[i][ROTATE_F2]);
		rotate_corner_orient[i][ROTATE_R3] = rotate_R_on_corner_orient(rotate_corner_orient[i][ROTATE_R2]);
		rotate_corner_orient[i][ROTATE_U3] = rotate_U_on_corner_orient(rotate_corner_orient[i][ROTATE_U2]);
		
		rotate_corner_orient[i][ROTATE_f] = i;
		rotate_corner_orient[i][ROTATE_b] = i;
		rotate_corner_orient[i][ROTATE_r] = i;
		rotate_corner_orient[i][ROTATE_l] = i;
		rotate_corner_orient[i][ROTATE_u] = i;
		rotate_corner_orient[i][ROTATE_d] = i;
		rotate_corner_orient[i][ROTATE_f2] = i;
		rotate_corner_orient[i][ROTATE_b2] = i;
		rotate_corner_orient[i][ROTATE_r2] = i;
		rotate_corner_orient[i][ROTATE_l2] = i;
		rotate_corner_orient[i][ROTATE_u2] = i;
		rotate_corner_orient[i][ROTATE_d2] = i;
		rotate_corner_orient[i][ROTATE_f3] = i;
		rotate_corner_orient[i][ROTATE_b3] = i;
		rotate_corner_orient[i][ROTATE_r3] = i;
		rotate_corner_orient[i][ROTATE_l3] = i;
		rotate_corner_orient[i][ROTATE_u3] = i;
		rotate_corner_orient[i][ROTATE_d3] = i;

		rotate_corner_orient[i][ROTATE_Ffb] = rotate_corner_orient[i][ROTATE_F];
		rotate_corner_orient[i][ROTATE_Rrl] = rotate_corner_orient[i][ROTATE_R];
		rotate_corner_orient[i][ROTATE_Uud] = rotate_corner_orient[i][ROTATE_U];
		rotate_corner_orient[i][ROTATE_Ffb2] = rotate_corner_orient[i][ROTATE_F2];
		rotate_corner_orient[i][ROTATE_Rrl2] = rotate_corner_orient[i][ROTATE_R2];
		rotate_corner_orient[i][ROTATE_Uud2] = rotate_corner_orient[i][ROTATE_U2];
		rotate_corner_orient[i][ROTATE_Ffb3] = rotate_corner_orient[i][ROTATE_F3];
		rotate_corner_orient[i][ROTATE_Rrl3] = rotate_corner_orient[i][ROTATE_R3];
		rotate_corner_orient[i][ROTATE_Uud3] = rotate_corner_orient[i][ROTATE_U3];
	}
}

void fill_rotate_corner_perm(unsigned short rotate_corner_perm[][ROTATE_NUMBER])
{
	unsigned short i;
	printf("fill rotate corner perm\n");
	for (i=0;i<CORNER_PERM_MAX_PACK;i++)
	{
		rotate_corner_perm[i][ROTATE_F] = rotate_F_on_corner_perm(i);
		rotate_corner_perm[i][ROTATE_R] = rotate_R_on_corner_perm(i);
		rotate_corner_perm[i][ROTATE_U] = rotate_U_on_corner_perm(i);
		rotate_corner_perm[i][ROTATE_F2] = rotate_F_on_corner_perm(rotate_corner_perm[i][ROTATE_F]);
		rotate_corner_perm[i][ROTATE_R2] = rotate_R_on_corner_perm(rotate_corner_perm[i][ROTATE_R]);
		rotate_corner_perm[i][ROTATE_U2] = rotate_U_on_corner_perm(rotate_corner_perm[i][ROTATE_U]);
		rotate_corner_perm[i][ROTATE_F3] = rotate_F_on_corner_perm(rotate_corner_perm[i][ROTATE_F2]);
		rotate_corner_perm[i][ROTATE_R3] = rotate_R_on_corner_perm(rotate_corner_perm[i][ROTATE_R2]);
		rotate_corner_perm[i][ROTATE_U3] = rotate_U_on_corner_perm(rotate_corner_perm[i][ROTATE_U2]);
		
		rotate_corner_perm[i][ROTATE_f] = i;
		rotate_corner_perm[i][ROTATE_b] = i;
		rotate_corner_perm[i][ROTATE_r] = i;
		rotate_corner_perm[i][ROTATE_l] = i;
		rotate_corner_perm[i][ROTATE_u] = i;
		rotate_corner_perm[i][ROTATE_d] = i;
		rotate_corner_perm[i][ROTATE_f2] = i;
		rotate_corner_perm[i][ROTATE_b2] = i;
		rotate_corner_perm[i][ROTATE_r2] = i;
		rotate_corner_perm[i][ROTATE_l2] = i;
		rotate_corner_perm[i][ROTATE_u2] = i;
		rotate_corner_perm[i][ROTATE_d2] = i;
		rotate_corner_perm[i][ROTATE_f3] = i;
		rotate_corner_perm[i][ROTATE_b3] = i;
		rotate_corner_perm[i][ROTATE_r3] = i;
		rotate_corner_perm[i][ROTATE_l3] = i;
		rotate_corner_perm[i][ROTATE_u3] = i;
		rotate_corner_perm[i][ROTATE_d3] = i;

		rotate_corner_perm[i][ROTATE_Ffb] = rotate_corner_perm[i][ROTATE_F];
		rotate_corner_perm[i][ROTATE_Rrl] = rotate_corner_perm[i][ROTATE_R];
		rotate_corner_perm[i][ROTATE_Uud] = rotate_corner_perm[i][ROTATE_U];
		rotate_corner_perm[i][ROTATE_Ffb2] = rotate_corner_perm[i][ROTATE_F2];
		rotate_corner_perm[i][ROTATE_Rrl2] = rotate_corner_perm[i][ROTATE_R2];
		rotate_corner_perm[i][ROTATE_Uud2] = rotate_corner_perm[i][ROTATE_U2];
		rotate_corner_perm[i][ROTATE_Ffb3] = rotate_corner_perm[i][ROTATE_F3];
		rotate_corner_perm[i][ROTATE_Rrl3] = rotate_corner_perm[i][ROTATE_R3];
		rotate_corner_perm[i][ROTATE_Uud3] = rotate_corner_perm[i][ROTATE_U3];
		}
}

void fill_rotate_center(unsigned short rotate_center[][ROTATE_NUMBER])
{
	unsigned short i;
	printf("fill rotate center\n");
	for (i=0;i<CENTER_MAX_PACK;i++)
	{
		rotate_center[i][ROTATE_F] = rotate_F_on_center(i);
		rotate_center[i][ROTATE_R] = rotate_R_on_center(i);
		rotate_center[i][ROTATE_U] = rotate_U_on_center(i);
		rotate_center[i][ROTATE_F2] = rotate_F_on_center(rotate_center[i][ROTATE_F]);
		rotate_center[i][ROTATE_R2] = rotate_R_on_center(rotate_center[i][ROTATE_R]);
		rotate_center[i][ROTATE_U2] = rotate_U_on_center(rotate_center[i][ROTATE_U]);
		rotate_center[i][ROTATE_F3] = rotate_F_on_center(rotate_center[i][ROTATE_F2]);
		rotate_center[i][ROTATE_R3] = rotate_R_on_center(rotate_center[i][ROTATE_R2]);
		rotate_center[i][ROTATE_U3] = rotate_U_on_center(rotate_center[i][ROTATE_U2]);
		
		rotate_center[i][ROTATE_f] = rotate_f_on_center(i);
		rotate_center[i][ROTATE_b] = rotate_b_on_center(i);
		rotate_center[i][ROTATE_r] = rotate_r_on_center(i);
		rotate_center[i][ROTATE_l] = rotate_l_on_center(i);
		rotate_center[i][ROTATE_u] = rotate_u_on_center(i);
		rotate_center[i][ROTATE_d] = rotate_d_on_center(i);
		rotate_center[i][ROTATE_f2] = rotate_f_on_center(rotate_center[i][ROTATE_f]);
		rotate_center[i][ROTATE_b2] = rotate_b_on_center(rotate_center[i][ROTATE_b]);
		rotate_center[i][ROTATE_r2] = rotate_r_on_center(rotate_center[i][ROTATE_r]);
		rotate_center[i][ROTATE_l2] = rotate_l_on_center(rotate_center[i][ROTATE_l]);
		rotate_center[i][ROTATE_u2] = rotate_u_on_center(rotate_center[i][ROTATE_u]);
		rotate_center[i][ROTATE_d2] = rotate_d_on_center(rotate_center[i][ROTATE_d]);
		rotate_center[i][ROTATE_f3] = rotate_f_on_center(rotate_center[i][ROTATE_f2]);
		rotate_center[i][ROTATE_b3] = rotate_b_on_center(rotate_center[i][ROTATE_b2]);
		rotate_center[i][ROTATE_r3] = rotate_r_on_center(rotate_center[i][ROTATE_r2]);
		rotate_center[i][ROTATE_l3] = rotate_l_on_center(rotate_center[i][ROTATE_l2]);
		rotate_center[i][ROTATE_u3] = rotate_u_on_center(rotate_center[i][ROTATE_u2]);
		rotate_center[i][ROTATE_d3] = rotate_d_on_center(rotate_center[i][ROTATE_d2]);

		rotate_center[i][ROTATE_Ffb3] = rotate_b_on_center(rotate_f_on_center(rotate_f_on_center(rotate_f_on_center(rotate_center[i][ROTATE_F3]))));
		rotate_center[i][ROTATE_Rrl3] = rotate_l_on_center(rotate_r_on_center(rotate_r_on_center(rotate_r_on_center(rotate_center[i][ROTATE_R3]))));
		rotate_center[i][ROTATE_Uud3] = rotate_d_on_center(rotate_u_on_center(rotate_u_on_center(rotate_u_on_center(rotate_center[i][ROTATE_U3]))));
		rotate_center[i][ROTATE_Ffb2] = rotate_b_on_center(rotate_b_on_center(rotate_f_on_center(rotate_f_on_center(rotate_center[i][ROTATE_F2]))));
		rotate_center[i][ROTATE_Rrl2] = rotate_l_on_center(rotate_l_on_center(rotate_r_on_center(rotate_r_on_center(rotate_center[i][ROTATE_R2]))));
		rotate_center[i][ROTATE_Uud2] = rotate_d_on_center(rotate_d_on_center(rotate_u_on_center(rotate_u_on_center(rotate_center[i][ROTATE_U2]))));
		rotate_center[i][ROTATE_Ffb] = rotate_b_on_center(rotate_b_on_center(rotate_b_on_center(rotate_F_on_center(rotate_center[i][ROTATE_f]))));
		rotate_center[i][ROTATE_Rrl] = rotate_l_on_center(rotate_l_on_center(rotate_l_on_center(rotate_R_on_center(rotate_center[i][ROTATE_r]))));
		rotate_center[i][ROTATE_Uud] = rotate_d_on_center(rotate_d_on_center(rotate_d_on_center(rotate_U_on_center(rotate_center[i][ROTATE_u]))));
	}
}

void fill_rotate_edge(unsigned short rotate_edge[][ROTATE_NUMBER])
{
	unsigned short i;
	printf("fill rotate edge\n");
	for (i=0;i < EDGE_MAX_PACK;i++)
	{
		rotate_edge[i][ROTATE_F] = rotate_F_on_edge(i);
		rotate_edge[i][ROTATE_R] = rotate_R_on_edge(i);
		rotate_edge[i][ROTATE_U] = rotate_U_on_edge(i);
		rotate_edge[i][ROTATE_F2] = rotate_F_on_edge(rotate_edge[i][ROTATE_F]);
		rotate_edge[i][ROTATE_R2] = rotate_R_on_edge(rotate_edge[i][ROTATE_R]);
		rotate_edge[i][ROTATE_U2] = rotate_U_on_edge(rotate_edge[i][ROTATE_U]);
		rotate_edge[i][ROTATE_F3] = rotate_F_on_edge(rotate_edge[i][ROTATE_F2]);
		rotate_edge[i][ROTATE_R3] = rotate_R_on_edge(rotate_edge[i][ROTATE_R2]);
		rotate_edge[i][ROTATE_U3] = rotate_U_on_edge(rotate_edge[i][ROTATE_U2]);
		
		rotate_edge[i][ROTATE_f] = rotate_f_on_edge(i);
		rotate_edge[i][ROTATE_b] = rotate_b_on_edge(i);
		rotate_edge[i][ROTATE_r] = rotate_r_on_edge(i);
		rotate_edge[i][ROTATE_l] = rotate_l_on_edge(i);
		rotate_edge[i][ROTATE_u] = rotate_u_on_edge(i);
		rotate_edge[i][ROTATE_d] = rotate_d_on_edge(i);
		rotate_edge[i][ROTATE_f2] = rotate_f_on_edge(rotate_edge[i][ROTATE_f]);
		rotate_edge[i][ROTATE_b2] = rotate_b_on_edge(rotate_edge[i][ROTATE_b]);
		rotate_edge[i][ROTATE_r2] = rotate_r_on_edge(rotate_edge[i][ROTATE_r]);
		rotate_edge[i][ROTATE_l2] = rotate_l_on_edge(rotate_edge[i][ROTATE_l]);
		rotate_edge[i][ROTATE_u2] = rotate_u_on_edge(rotate_edge[i][ROTATE_u]);
		rotate_edge[i][ROTATE_d2] = rotate_d_on_edge(rotate_edge[i][ROTATE_d]);
		rotate_edge[i][ROTATE_f3] = rotate_f_on_edge(rotate_edge[i][ROTATE_f2]);
		rotate_edge[i][ROTATE_b3] = rotate_b_on_edge(rotate_edge[i][ROTATE_b2]);
		rotate_edge[i][ROTATE_r3] = rotate_r_on_edge(rotate_edge[i][ROTATE_r2]);
		rotate_edge[i][ROTATE_l3] = rotate_l_on_edge(rotate_edge[i][ROTATE_l2]);
		rotate_edge[i][ROTATE_u3] = rotate_u_on_edge(rotate_edge[i][ROTATE_u2]);
		rotate_edge[i][ROTATE_d3] = rotate_d_on_edge(rotate_edge[i][ROTATE_d2]);

		rotate_edge[i][ROTATE_Ffb3] = rotate_b_on_edge(rotate_f_on_edge(rotate_f_on_edge(rotate_f_on_edge(rotate_edge[i][ROTATE_F3]))));
		rotate_edge[i][ROTATE_Rrl3] = rotate_l_on_edge(rotate_r_on_edge(rotate_r_on_edge(rotate_r_on_edge(rotate_edge[i][ROTATE_R3]))));
		rotate_edge[i][ROTATE_Uud3] = rotate_d_on_edge(rotate_u_on_edge(rotate_u_on_edge(rotate_u_on_edge(rotate_edge[i][ROTATE_U3]))));
		rotate_edge[i][ROTATE_Ffb2] = rotate_b_on_edge(rotate_b_on_edge(rotate_f_on_edge(rotate_f_on_edge(rotate_edge[i][ROTATE_F2]))));
		rotate_edge[i][ROTATE_Rrl2] = rotate_l_on_edge(rotate_l_on_edge(rotate_r_on_edge(rotate_r_on_edge(rotate_edge[i][ROTATE_R2]))));
		rotate_edge[i][ROTATE_Uud2] = rotate_d_on_edge(rotate_d_on_edge(rotate_u_on_edge(rotate_u_on_edge(rotate_edge[i][ROTATE_U2]))));
		rotate_edge[i][ROTATE_Ffb] = rotate_b_on_edge(rotate_b_on_edge(rotate_b_on_edge(rotate_F_on_edge(rotate_edge[i][ROTATE_f]))));
		rotate_edge[i][ROTATE_Rrl] = rotate_l_on_edge(rotate_l_on_edge(rotate_l_on_edge(rotate_R_on_edge(rotate_edge[i][ROTATE_r]))));
		rotate_edge[i][ROTATE_Uud] = rotate_d_on_edge(rotate_d_on_edge(rotate_d_on_edge(rotate_U_on_edge(rotate_edge[i][ROTATE_u]))));
	}
}
