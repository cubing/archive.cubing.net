#define  ROTATE_F       0
#define  ROTATE_R       1
#define  ROTATE_U       2
#define  ROTATE_F2      3
#define  ROTATE_R2      4
#define  ROTATE_U2      5
#define  ROTATE_F3      6
#define  ROTATE_R3      7
#define  ROTATE_U3      8

#define  ROTATE_f       9
#define  ROTATE_b       10
#define  ROTATE_r       11
#define  ROTATE_l       12
#define  ROTATE_u       13
#define  ROTATE_d       14
#define  ROTATE_f2      15
#define  ROTATE_b2      16
#define  ROTATE_r2      17
#define  ROTATE_l2      18
#define  ROTATE_u2      19
#define  ROTATE_d2      20
#define  ROTATE_f3      21
#define  ROTATE_b3      22
#define  ROTATE_r3      23
#define  ROTATE_l3      24
#define  ROTATE_u3      25
#define  ROTATE_d3      26

#define  ROTATE_Ffb     27
#define  ROTATE_Rrl     28
#define  ROTATE_Uud     29
#define  ROTATE_Ffb2    30
#define  ROTATE_Rrl2    31
#define  ROTATE_Uud2    32
#define  ROTATE_Ffb3    33
#define  ROTATE_Rrl3    34
#define  ROTATE_Uud3    35

#define  ROTATE_NUMBER  36


void fill_rotate_corner_orient(unsigned short(*)[ROTATE_NUMBER]);

void fill_rotate_corner_perm(unsigned short(*)[ROTATE_NUMBER]);

void fill_rotate_center(unsigned short(*)[ROTATE_NUMBER]);

void fill_rotate_edge(unsigned short(*)[ROTATE_NUMBER]);

