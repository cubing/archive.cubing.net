#include "rotate_center.h"
#include "rotate_edge.h"
#include "rotate_corner_perm.h"
#include "rotate_corner_orient.h"
#include "main.h"

#define LIFE_UNIVERSE_AND_EVERYTHING  42


void fill_prune_center(unsigned char*, int, unsigned short(*)[ROTATE_NUMBER]);

void fill_prune_corner(unsigned char(*)[CORNER_ORIENT_MAX_PACK], unsigned short, unsigned short, unsigned short(*)[ROTATE_NUMBER], unsigned short(*)[ROTATE_NUMBER]);

void fill_prune_edge(unsigned char*, int, unsigned short(*)[ROTATE_NUMBER]);

