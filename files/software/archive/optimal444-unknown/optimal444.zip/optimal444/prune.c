#include "prune.h"
#include <stdio.h>
//#include "structure.h"

void fill_prune_center(unsigned char prune_center[], int solved, unsigned short rotate_center[][ROTATE_NUMBER])
{
	int found;
	int m, i, t;
	printf("fill prune center\n");
	for (i = 0; i < CENTER_MAX_PACK; i++)
		prune_center[i] = LIFE_UNIVERSE_AND_EVERYTHING;

	prune_center[solved] = 0;
	found = 1;
	m = 0;
	while (found)
	{ 
		m++;
		found = 0;
		for (i = 0; i < CENTER_MAX_PACK; i++)
		{
			if (prune_center[i] == (m-1))
			{
				found = 1;
				for (t = 0; t < ROTATE_NUMBER; t++)
					if (prune_center[rotate_center[i][t]] == LIFE_UNIVERSE_AND_EVERYTHING)
						prune_center[rotate_center[i][t]] = m;
			}
		}
	}
	//cout << "center max : " << m << endl;
}

void fill_prune_corner(unsigned char prune_corner[][CORNER_ORIENT_MAX_PACK], unsigned short solved_p, unsigned short solved_o, unsigned short rotate_corner_perm[][ROTATE_NUMBER], unsigned short rotate_corner_orient[][ROTATE_NUMBER])
{
	int found = 1;
	int m = 0, i, j, k;
	printf("fill prune corner\n");
	for (i = 0; i < CORNER_PERM_MAX_PACK; i++)
		for (j = 0; j < CORNER_ORIENT_MAX_PACK; j++)
			prune_corner[i][j] = LIFE_UNIVERSE_AND_EVERYTHING;
	prune_corner[solved_p][solved_o] = 0;
	while (found)
	{ 
		m++;
		found = 0;
		for (i = 0; i < CORNER_PERM_MAX_PACK; i++)
			for (j = 0; j < CORNER_ORIENT_MAX_PACK; j++)
				if (prune_corner[i][j] == (m-1))
				{
					found = 1;
					for (k = 0; k < ROTATE_NUMBER; k++)
						if (prune_corner[rotate_corner_perm[i][k]][rotate_corner_orient[j][k]] == LIFE_UNIVERSE_AND_EVERYTHING)
							prune_corner[rotate_corner_perm[i][k]][rotate_corner_orient[j][k]] = m;
				}
	}
	//printf("max prune : %d",m - 1);
}

void fill_prune_edge(unsigned char prune_edge[], int solved, unsigned short rotate_edge[][ROTATE_NUMBER])
{
	int found;
	int m, i, t;
	printf("fill prune edge\n");
	for (i = 0; i < EDGE_MAX_PACK; i++)
		prune_edge[i] = LIFE_UNIVERSE_AND_EVERYTHING;

	prune_edge[solved] = 0;
	found = 1;
	m = 0;
	while (found)
	{ 
		m++;
		found = 0;
		for (i = 0; i < EDGE_MAX_PACK; i++)
		{
			if (prune_edge[i] == (m-1))
			{
				found = 1;
				for (t = 0; t < ROTATE_NUMBER; t++)
					if (prune_edge[rotate_edge[i][t]] == LIFE_UNIVERSE_AND_EVERYTHING)
						prune_edge[rotate_edge[i][t]] = m;
			}
		}
	}
	//cout << "edge max : " << m << endl;
}

