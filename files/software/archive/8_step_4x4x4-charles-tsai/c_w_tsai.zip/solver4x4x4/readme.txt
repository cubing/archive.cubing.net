solver7v2.exe
solver8v2.exe

for Windows XP and Vista


To use:
Open "Command Prompt" and navigate to the proper directory.
Type "solver7v2" or "solver8v2".
Enter scramble when prompted. 
Please limit your scramble to 300 characters.

To quit:
Press Return without entering a scramble.

To abort:
If the search is taking too long and you wish to abort it, press Control-C.


Copying and Pasting within the Command Prompt window:
Right click on Command Prompt in the Task Bar. Select Properties.
In the Options tab, select "QuickEdit Mode"

To copy:
Highlight with left mouse button then right click.

To paste:
Right click.


CWT
