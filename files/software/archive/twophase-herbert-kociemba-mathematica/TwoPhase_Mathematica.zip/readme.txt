The package contains a pure Mathematica implementation of the Two-Phase-Algorithm.
The speed is very slow compared to the Cube Explorer program.
On the other hand the Mathematica code is very short, so it might be interesting from
a more mathematical point of view.

The notebook TwoPhase.nb contains a detailed explanation of the supplied functions.


Herbert Kociemba

October 2010